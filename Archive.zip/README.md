# Personal Website

Codebase for personal website

HTML, CSS, JQuery, FancyApp

Bootstrapped with https://github.com/blackrockdigital/startbootstrap-scrolling-nav
